
JEITA Public Morphologically Tagged Corpus (in ChaSen format)
JEITA 形態素解析済みコーパス (ChaSen 形式)

Created and distributed by Masato Hagiwara (http://lilyx.net/)
作成＆配布 萩原 正人 (http://lilyx.net/)

* About this corpus - 本コーパスについて

This copurs, JEITA Public Morphologically Tagged Corpus (in ChaSen format), is a public, automatically tagged (morphologically analyzed) corpus of Project Sugita Genpaku (http://www.genpaku.org/) and Aozora Bunko (http://www.aozora.gr.jp/), which themselves are freely available text collections like Project Gutenberg. The corpus data is originally distributed as "JEITA Public Morphologically Tagged Corpus" here:

本コーパス 「JEITA 形態素解析済みコーパス (ChaSen 形式)」は、プロジェクト杉田玄白 (http://www.genpaku.org/) と青空文庫 (http://www.aozora.gr.jp/) のテキストを自動で形態素解析した、フリーで利用可能なタグ付きコーパスです。本コーパスは、本来、「JEITA 形態素解析済みコーパス」として、以下のページにおいて配布されているデータに基づいています。

http://nlp.kuee.kyoto-u.ac.jp/NLP_Portal/jeita_corpus/index.html

but the files included in this copurs are not the original distribution data of JEITA Public Morphologically Tagged Corpus but the ones which are converted into ChaSen's file formats for easier program access. For more information on the ChaSen morphological analyzer, you can refer to ChaSen's official site: http://chasen-legacy.sourceforge.jp/ .

ただし、本コーパスに含まれているファイルは上記JEITA 形態素解析済みコーパスの配布データそのものではなく、プログラムからのアクセスを容易にするために ChaSen のファイル形式に変換してあります。ChaSen の詳細についてはオフィシャルサイト http://chasen-legacy.sourceforge.jp/ を参考してください。

* Distributed files - 配布ファイル

_readme.txt - this readme file
xxxx.chasen - corpus file in ChaSen format (xxxx refers to document ID)
xxxx_copyright.html (or xxxx.html) - copyright file correspondig to xxxx.chasen

_readme.txt - 本 readme ファイル
xxxx.chasen - ChaSen 形式のコーパス本体ファイル (xxxx は文書 ID)
xxxx_copyright.html (もしくは xxxx.html) - xxxx.chasen に対応する版権情報ファイル

* Access by NLTK (Natural Language Toolkit) Corpus Reader - NLTK のコーパスリーダーを使って読み込む

Since this corpus is in ChaSen's format, it can be easily accessed via ChaSen corpus reader for NLTK distributed here:

本コーパスは ChaSen 形式であるため、NLTK のための ChaSen コーパスリーダー（以下で入手可能）を用いると簡単にアクセスできます:

http://lilyx.net/pages/nltkjapanesecorpus.html

For the detailed usage of ChaSen corpus reader, see the above URL.

ChaSen コーパスリーダーの使用法の詳細については、上記 URL を参照してください。

* Acknowledgement - 謝辞

I thank the members of JEITA 言語資源分科会, especially the leader Prof. Hitoshi Isahara for allowing the conversion and reditributon of their Morphlogically Tagged Corpus. I also thank the members of Project Sugita Genpaku and Aozora bunko, and the developers of ChaSen morphological analyzer.

本コーパスの元となった JEITA 形態素解析済みコーパスの変換および再配布の許可をいただいたJEITA 言語資源分科会の皆さま、特に委員長の井佐原均教授に感謝いたします。また、プロジェクト杉田玄白・青空文庫の公開、そして ChaSen の開発に携わる皆さまに感謝いたします。

